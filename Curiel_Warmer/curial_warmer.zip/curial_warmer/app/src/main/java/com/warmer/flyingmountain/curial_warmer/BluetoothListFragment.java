package com.warmer.flyingmountain.curial_warmer;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;


public class BluetoothListFragment extends Fragment {
    private HashMap<String, String> deviceMap;
    private ArrayList<String> hardwareInfo = new ArrayList<String>();
    private HashSet<String> hardwareinfo_set = new HashSet<String>();
    private static ListView bluetoothlist;
    public OnDataPass dataPasser;
    private String mDeviceAddress;

    private BluetoothAdapter mBluetoothAdapter;
    private boolean mScanning;
    private Handler mHandler;

    private BLEService mBluetoothLeService;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BLEService.LocalBinder) service).getService();

            if (!mBluetoothLeService.initialize()) {
                Log.e("BT_LOG", "Unable to initialize Bluetooth");
            } else {
                mBluetoothLeService.connect(mDeviceAddress);
            }
        }
        @Override
        public void onServiceDisconnected(ComponentName componentName) {
                mBluetoothLeService = null;
        }
    };


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout .fragment_bluetooth_list, container, false);
        Button btn_scan = (Button)view.findViewById(R.id.btn_scan);
        btn_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "Scanning..", Toast.LENGTH_SHORT).show();
                startDiscovery();
            }
        });

        mHandler = new Handler();
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getActivity().getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        // Checks if Bluetooth is supported on the device.
        if (mBluetoothAdapter == null) {
            Log.i("BT_LOG","error_bluetooth_not_supported");
            return null;
        }

        updateScannedResult(view);

        return view;
    }

    public void updateScannedResult(View view){
        bluetoothlist = (ListView)view.findViewById(R.id.btListView);
        Bundle getBundle = getArguments();
        if(getBundle != null) {
            Log.i("Fragment_log", "hardwarelist " + getBundle.getStringArrayList("hardwarelist").size());
            hardwareInfo.clear();
            hardwareinfo_set.clear();
            for (int i = 0; i < getBundle.getStringArrayList("hardwarelist").size(); i++) {
                Log.i("Fragment_log", "hardwarelist " + String.valueOf(getBundle.getStringArrayList("hardwarelist").get(i)));
                hardwareinfo_set.add(String.valueOf(getBundle.getStringArrayList("hardwarelist").get(i)));
            }
            hardwareInfo = new ArrayList<>(hardwareinfo_set);
        }
        else{
            Log.i("Fragment_log", String.valueOf("fragment"));
        }
        hardwareInfo = new ArrayList<>(hardwareinfo_set);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, hardwareInfo);
        bluetoothlist.setAdapter(arrayAdapter);
        bluetoothlistOnItemClickListener(bluetoothlist);
    }

    public void startDiscovery(){
        if (! this.isDetached()) {
            Log.i("BT_LOG","fragment transaction");
            getFragmentManager().beginTransaction()
                    .detach(this)
                    .attach(this)
                    .commit();
        }
        ((MainActivity)getActivity()).scanLeDevice(true);
    }


    public void bluetoothlistOnItemClickListener(final ListView listview){
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, final int i, long l) {
                final View selectedItem = listview.getChildAt(i);
                final String hardwareInfoStr = (String)adapter.getItemAtPosition(i);
                selectedItem.setAlpha(.5f);
                ((TextView)selectedItem).setText(adapter.getItemAtPosition(i)+"\n\t\t\tConnecting..");
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        ((TextView) selectedItem).setText(hardwareInfoStr);
                        selectedItem.setAlpha(1);
                    }
                }, 3000);
                Log.i("Fragment_log", "set alpha");
                Log.i("Fragment_log", (String) adapter.getItemAtPosition(i));
                mDeviceAddress = ((String) adapter.getItemAtPosition(i)).split("@")[1];
                ((MainActivity)getActivity()).connectDevice(mDeviceAddress);
                Toast.makeText(getActivity(), "Connecting..", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public interface OnDataPass {
        void onDataPass(HashMap data);
    }

    public void passData(HashMap deviceMap) {
        while(deviceMap.entrySet().iterator().hasNext()) {
            Log.i("fragment", deviceMap.entrySet().iterator().next().toString());
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        //deviceMap = ((MainActivity) getActivity()).sendData();
        //Log.i("bluetooth_fragment",String.valueOf(deviceMap.size()));

        /*
        while (deviceMap.entrySet().iterator().hasNext()) {
            Log.i("bluetooth_fragment", deviceMap.entrySet().iterator().next().toString());

        }*/
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
    private BluetoothAdapter.LeScanCallback mLeScanCallback =
        new BluetoothAdapter.LeScanCallback() {
            @Override
            public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
                hardwareinfo_set.add(device.getName()+"@"+device.getAddress());
                for(String hardware : hardwareinfo_set){
                    Log.i("BT_LOG",hardware);
                }
            }
    };
}
