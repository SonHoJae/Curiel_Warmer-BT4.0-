package com.warmer.flyingmountain.curial_warmer;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;


public class MainActivity extends FragmentActivity {

    LocationManager mLM;

    //MARK: Values
    private static final String READ_CHARACTERISTIC_ID = "00000011-0000-1000-8000-00805F9B34FB";
    private static final String WRITE_CHARACTERISTIC_ID = "00000011-0000-1000-8000-00805F9B34FB";
    private static final int MAX_TEMPERATURE = 50;
    private static final int MIN_TEMPERATURE = 37;

    private final String TAG = "BLUETOOTH";

    private BluetoothGattCharacteristic characteristicTx;
    private BluetoothGattService gattService;
    private BluetoothAdapter mBluetoothAdapter;
    private BLEService mBluetoothLeService;
    private boolean mScanning;
    private String mDeviceAddress;
    private Handler mHandler;
    private static final long SCAN_PERIOD = 5000;

    byte requiredTemperature = 0x28;
    private List<String> hardware_list;
    private HashSet<String> hardwareIist_Set;
    Button btn_connect;
    ImageButton btn_on;
    ImageButton btn_off;
    ImageButton btn_up;
    ImageButton btn_down;
    ProgressBar progressbar_control_temp;
    TextView battery_status;
    TextView temperature_status;
    TextView tempView;

    private boolean isPowerOn = false;
    private boolean isConnected = false;
    private boolean mFoundGatt = false;

    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BLEService.LocalBinder) service).getService();

            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }

            mBluetoothLeService.connect(mDeviceAddress);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };



    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            Log.d(TAG, "This is action: " + action);
            if (BLEService.ACTION_GATT_CONNECTED.equals(action)) {
                //appConnected();

                isConnected = true;
                Log.i(TAG,"Connected");
                tempView.setText("Connected! Here is hojae");

                invalidateOptionsMenu();
            } else if (BLEService.ACTION_GATT_DISCONNECTED.equals(action)) {
                isConnected = false;
                Log.i(TAG,"disconnected");

                invalidateOptionsMenu();
            } else if (BLEService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                gattService = mBluetoothLeService.getSupportedGattService();
                if (gattService != null) {
                    characteristicTx = gattService.getCharacteristic(UUID.fromString(BLEGattAttributes.BLE_SHIELD_TX));
                    if (characteristicTx != null) {
                        mFoundGatt = true;
                        //appConnected();
                    }
                }

                Log.i(TAG,"ACTION_GATT_SERVICES_DISCOVERED");
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //registerLocationUpdates();

        Intent gattServiceIntent = new Intent(this, BLEService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);

        initBLE();
        initUI();
        initClient();

    }

    void initBLE(){
        mHandler = new Handler();

        // Use this check to determine whether BLE is supported on the device.  Then you can
        // selectively disable BLE-related features.
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
            finish();
        }

        // Initializes a Bluetooth adapter.  For API level 18 and above, get a reference to
        // BluetoothAdapter through BluetoothManager.
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        // Checks if Bluetooth is supported on the device.
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
    }
    void initUI(){
        hardware_list = new ArrayList<String>();
        hardwareIist_Set = new HashSet<String>();
        btn_connect = (Button) findViewById(R.id.btn_connect);
        btn_on = (ImageButton) findViewById(R.id.btn_on);
        btn_off = (ImageButton) findViewById(R.id.btn_off);
        btn_up = (ImageButton) findViewById(R.id.btn_up);
        btn_down = (ImageButton) findViewById(R.id.btn_down);
        progressbar_control_temp = (ProgressBar) findViewById(R.id.progressbar_control_temp);
        progressbar_control_temp.setMax(MAX_TEMPERATURE - MIN_TEMPERATURE);
        progressbar_control_temp.setProgress(requiredTemperature - MIN_TEMPERATURE);
        temperature_status = (TextView) findViewById(R.id.txtView_Temperature);
        battery_status = (TextView) findViewById(R.id.txtView_battery);
        tempView = (TextView) findViewById(R.id.txtView_set_temp);
    }
    void initClient() {

        btn_connect.setEnabled(true);
        btn_connect.setOnClickListener(null);
        btn_connect.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {

                BluetoothListFragment bluetoothListFragment = new BluetoothListFragment();
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.activity_main, bluetoothListFragment)
                        .addToBackStack("fragment")
                        .commit();
            }
        });
    }

    public void onBackPressed() {
        Log.i(TAG,"onBackPressed "+String.valueOf(getSupportFragmentManager().getBackStackEntryCount()));
        scanLeDevice(false);
        if (getSupportFragmentManager().getBackStackEntryCount() > 0)
            getSupportFragmentManager().popBackStack();
        else {
            super.onBackPressed();
            android.os.Process.killProcess(android.os.Process.myPid());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        btn_connect.setBackgroundResource(android.R.drawable.btn_default);
        isConnected = false;
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
    //Connecting functions
    public void connectDevice(String mDeviceAddress) {
        mBluetoothLeService.connect(mDeviceAddress);
    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();

        intentFilter.addAction(BLEService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BLEService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BLEService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BLEService.ACTION_DATA_AVAILABLE);
        intentFilter.addAction("notification_event");

        return intentFilter;
    }
    //Scanning functions
    public void scanLeDevice(final boolean enable) {
        if (enable) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mScanning = false;
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    invalidateOptionsMenu();
                }
            }, SCAN_PERIOD);

            mScanning = true;
            mBluetoothAdapter.startLeScan(mLeScanCallback);
        } else {
            mScanning = false;
            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }
    }

        private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {

                @Override
                public void onLeScan(final BluetoothDevice device, int rssi, byte[] scanRecord) {
                    hardwareIist_Set.add(device.getName()+"@"+device.getAddress());
                    for(String hardware : hardwareIist_Set){
                        Log.i("BT_LOG",hardware);
                    }
                    Log.i(TAG,"onBackPressed "+String.valueOf(getSupportFragmentManager().getBackStackEntryCount()));
                    BluetoothListFragment bluetoothListFragment = new BluetoothListFragment();
                    Bundle b = new Bundle();
                    hardware_list.clear();
                    hardware_list = new ArrayList<>(hardwareIist_Set);
                    b.putStringArrayList("hardwarelist", (ArrayList<String>) hardware_list);
                    bluetoothListFragment.setArguments(b);
                    getSupportFragmentManager().popBackStack();
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.activity_main, bluetoothListFragment)
                            .addToBackStack(null)
                            .commit();
                }
            };
}

